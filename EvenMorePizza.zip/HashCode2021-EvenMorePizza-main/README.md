# HashCode2021-EvenMorePizza
My solution to the Google coding competition HashCode 2021's practice problem - Even More Pizza

Video explanation of this solution and the problem statement: https://youtu.be/STIRFdfpIqQ

---

The score of this solution add up to (702,288,546)

A – Example => 41 points

B – A little bit of everything => 5,188 points

C – Many ingredients => 687,959,285 points

D – Many pizzas => 6,034,379 points

E – Many teams => 8,289,653 points


---


If you can optimize upon my solution feel free to do so and share it with me on [twitter @_CodeLife_](https://twitter.com/_CodeLife_)

Best of luck! ^^
